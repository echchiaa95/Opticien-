import React, { useEffect, useMemo, useState } from 'react';
import { CalendarDays, CheckCircle2, Glasses, MapPin, Minus, Phone, Plus, ShoppingBag, ShoppingCart, Store } from 'lucide-react';
import { supabase, supabaseConfigured } from './supabase';
import './storefront.css';

const money = n => new Intl.NumberFormat('fr-MA', { style: 'currency', currency: 'MAD', maximumFractionDigits: 2 }).format(Number(n || 0));
const today = new Date(Date.now() + 86400000).toISOString().slice(0, 10);

export default function PublicStorefront({ slug }) {
  const [lang, setLang] = useState(() => localStorage.getItem('opticflow-language') || 'ar');
  const [dark, setDark] = useState(() => localStorage.getItem('opticflow-theme') === 'dark');
  useEffect(() => { localStorage.setItem('opticflow-language', lang); document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'; }, [lang]);
  useEffect(() => { localStorage.setItem('opticflow-theme', dark ? 'dark' : 'light'); }, [dark]);
  const [store, setStore] = useState(null);
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('shop');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [customer, setCustomer] = useState({ name: '', phone: '', city: '', address: '' });
  const [booking, setBooking] = useState({ name: '', phone: '', service: 'اختيار النظارات', date: today, time: '11:00' });

  useEffect(() => {
    let active = true;
    async function load() {
      setLoading(true); setError('');
      if (!supabaseConfigured) { setError('المتجر غير متصل بقاعدة البيانات بعد. أضف إعدادات Supabase ثم أعد النشر.'); setLoading(false); return; }
      const { data, error: rpcError } = await supabase.rpc('get_public_storefront', { p_slug: slug });
      if (!active) return;
      if (rpcError || !data?.shop) setError('لم يتم العثور على هذا المتجر أو أنه غير متاح حاليًا.');
      else { setStore(data.shop); setProducts(data.products || []); }
      setLoading(false);
    }
    load(); return () => { active = false; };
  }, [slug]);

  const cartItems = useMemo(() => products.filter(p => cart[p.id] > 0).map(p => ({ ...p, quantity: cart[p.id] })), [products, cart]);
  const subtotal = cartItems.reduce((sum, p) => sum + Number(p.price) * p.quantity, 0);
  const delivery = Number(store?.settings?.delivery_fee || 0);
  const total = subtotal + (cartItems.length ? delivery : 0);
  const updateQty = (id, delta) => setCart(prev => { const next = { ...prev }; const available = Number(products.find(p => p.id === id)?.stock ?? 20); const qty = Math.max(0, Math.min(available, (next[id] || 0) + delta)); if (qty) next[id] = qty; else delete next[id]; return next; });
  const setCustomerField = e => setCustomer(p => ({ ...p, [e.target.name]: e.target.value }));
  const setBookingField = e => setBooking(p => ({ ...p, [e.target.name]: e.target.value }));

  async function submitOrder(e) {
    e.preventDefault(); setNotice('');
    if (!cartItems.length) return setNotice('أضف منتجًا واحدًا على الأقل إلى السلة.');
    setBusy(true);
    const { data, error: rpcError } = await supabase.rpc('create_public_cod_order', {
      p_slug: slug,
      p_customer: { name: customer.name.trim(), phone: customer.phone.trim(), city: customer.city.trim(), address: customer.address.trim() },
      p_items: cartItems.map(p => ({ product_id: p.id, quantity: p.quantity }))
    });
    setBusy(false);
    if (rpcError || data?.error) return setNotice(data?.error || 'تعذر تسجيل الطلب. تحقق من البيانات وحاول مجددًا.');
    setNotice(`تم تسجيل طلبك بنجاح. رقم الطلب: ${data.order_number}. الدفع عند الاستلام.`);
    setCart({}); setCustomer({ name: '', phone: '', city: '', address: '' });
  }

  async function submitBooking(e) {
    e.preventDefault(); setNotice(''); setBusy(true);
    const startsAt = new Date(`${booking.date}T${booking.time}:00`).toISOString();
    const { data, error: rpcError } = await supabase.rpc('create_public_appointment', {
      p_slug: slug,
      p_customer: { name: booking.name.trim(), phone: booking.phone.trim() },
      p_service: booking.service,
      p_starts_at: startsAt
    });
    setBusy(false);
    if (rpcError || data?.error) return setNotice(data?.error || 'تعذر تسجيل الموعد. قد يكون الوقت محجوزًا بالفعل.');
    setNotice(`تم إرسال طلب الموعد بنجاح. المرجع: ${data.appointment_id}. انتظر تأكيد المحل.`);
    setBooking(p => ({ ...p, name: '', phone: '' }));
  }

  if (loading) return <div className="public-state"><div className="store-loader"/><p>جارٍ تحميل المتجر…</p></div>;
  if (error) return <div className="public-state"><Store size={40}/><h1>المتجر غير متاح</h1><p>{error}</p><a href="./">العودة إلى لوحة المنصة</a></div>;
  const settings = store.settings || {};
  const wa = String(settings.whatsapp || store.whatsapp || store.phone || '').replace(/\D/g, '');
  return <div className={'public-store '+(dark?'store-dark':'')} dir={lang === 'ar' ? 'rtl' : 'ltr'} style={{ '--store-primary': settings.primary_color || '#172f46', '--store-accent': settings.accent_color || '#c6a66b' }}>
    <header className="public-header"><a className="public-brand" href={`?store=${encodeURIComponent(slug)}`}><span className="public-logo">{store.logo_url ? <img src={store.logo_url} alt="Logo"/> : <Glasses/>}</span><span><b>{store.name}</b><small>{settings.tagline || 'Votre vision, notre priorité'}</small></span></a><nav><button className={tab === 'shop' ? 'active' : ''} onClick={() => { setTab('shop'); setNotice(''); }}>المتجر</button><button className={tab === 'booking' ? 'active' : ''} onClick={() => { setTab('booking'); setNotice(''); }}>حجز موعد</button><button className={tab === 'cart' ? 'active' : ''} onClick={() => { setTab('cart'); setNotice(''); }}><ShoppingCart size={16}/> السلة ({cartItems.reduce((s,p)=>s+p.quantity,0)})</button></nav></header>
    <main>
      <section className="public-hero"><div className="public-hero-copy"><span className="public-eyebrow">VISION · STYLE · EXPERTISE</span><h1>{settings.hero_title || 'رؤيتك أوضح. إطلالتك أجمل.'}</h1><p>{settings.hero_text || 'اكتشف تشكيلتنا من النظارات الطبية والشمسية، واحجز موعدك بكل سهولة.'}</p><div className="public-hero-actions"><button onClick={() => setTab('shop')}>اكتشف التشكيلة <ShoppingBag size={17}/></button><button className="public-ghost" onClick={() => setTab('booking')}>احجز موعدًا <CalendarDays size={17}/></button></div><div className="public-trust"><span><CheckCircle2/> منتجات مختارة</span><span><ShoppingBag/> الدفع عند الاستلام</span></div></div><div className="public-hero-art"><div className="lens-ring ring-one"/><div className="lens-ring ring-two"/><Glasses size={170} strokeWidth={1}/><span>SEE THE DIFFERENCE</span></div></section>
      {notice && <div className="public-notice" role="status">{notice}</div>}
      {tab === 'shop' && <section className="public-section"><div className="public-section-title"><div><span className="public-eyebrow">OUR COLLECTION</span><h2>اكتشف منتجاتنا</h2><p>اختر منتجاتك وأكمل الطلب بالدفع عند الاستلام.</p></div><span className="product-count">{products.length} منتج</span></div>{products.length ? <div className="public-products">{products.map(p => <article className="public-product" key={p.id}><div className="public-product-image">{p.image_urls?.[0] ? <img src={p.image_urls[0]} alt={p.name}/> : <Glasses size={68}/>}<span>{p.category}</span></div><div className="public-product-info"><small>{p.brand || store.name}</small><h3>{p.name}</h3><p>{p.description || 'تصميم أنيق وجودة مختارة بعناية.'}</p><div className="public-product-bottom"><b>{money(p.price)}</b><button aria-label="أضف إلى السلة" disabled={Number(p.stock) < 1} onClick={() => { updateQty(p.id, 1); setNotice('تمت إضافة المنتج إلى السلة.'); }}><Plus size={17}/></button></div>{Number(p.stock) < 1 && <small className="out-stock">غير متوفر حاليًا</small>}</div></article>)}</div> : <div className="public-empty"><Glasses size={38}/><h3>سيتم عرض المنتجات هنا</h3><p>لم يضف المتجر منتجات منشورة بعد.</p></div>}</section>}
      {tab === 'cart' && <section className="public-section public-checkout"><div className="public-section-title"><div><span className="public-eyebrow">YOUR ORDER</span><h2>السلة وإتمام الطلب</h2><p>الدفع نقدًا عند استلام الطلب.</p></div></div>{!cartItems.length ? <div className="public-empty"><ShoppingCart size={38}/><h3>سلتك فارغة</h3><button onClick={() => setTab('shop')}>العودة إلى المتجر</button></div> : <div className="checkout-grid"><div className="checkout-items">{cartItems.map(p => <div className="checkout-item" key={p.id}><div className="checkout-item-icon"><Glasses/></div><div className="checkout-item-copy"><b>{p.name}</b><small>{money(p.price)} للقطعة</small><div className="qty-control"><button onClick={() => updateQty(p.id,-1)}><Minus size={14}/></button><span>{p.quantity}</span><button disabled={p.quantity >= Number(p.stock)} onClick={() => updateQty(p.id,1)}><Plus size={14}/></button></div></div><strong>{money(p.price*p.quantity)}</strong></div>)}<div className="checkout-total"><span>المجموع الفرعي</span><b>{money(subtotal)}</b></div><div className="checkout-total"><span>التوصيل</span><b>{money(delivery)}</b></div><div className="checkout-total grand-total"><span>الإجمالي عند الاستلام</span><b>{money(total)}</b></div></div><form className="public-form" onSubmit={submitOrder}><h3>معلومات التوصيل</h3><label>الاسم الكامل<input required name="name" value={customer.name} onChange={setCustomerField} minLength={2} maxLength={100}/></label><label>رقم الهاتف<input required name="phone" type="tel" value={customer.phone} onChange={setCustomerField} pattern="[+0-9 ()-]{8,20}"/></label><label>المدينة<input required name="city" value={customer.city} onChange={setCustomerField} maxLength={80}/></label><label>العنوان بالتفصيل<textarea required name="address" value={customer.address} onChange={setCustomerField} minLength={5} maxLength={300}/></label><button className="public-submit" disabled={busy}>{busy ? 'جارٍ إرسال الطلب…' : <>تأكيد الطلب بالدفع عند الاستلام <ShoppingBag size={17}/></>}</button><small>يتم التحقق من الأسعار والمخزون داخل قاعدة البيانات قبل تسجيل الطلب.</small></form></div>}</section>}
      {tab === 'booking' && <section className="public-section public-booking"><div className="booking-intro"><span className="public-eyebrow">BOOK AN APPOINTMENT</span><h2>موعدك يبدأ من هنا</h2><p>أرسل طلب الموعد وسيقوم المحل بتأكيده. لا يُعد الموعد مؤكدًا حتى تتلقى التأكيد.</p><div className="booking-contact"><p><Phone size={16}/> {store.phone || 'اتصل بالمحل'}</p><p><MapPin size={16}/> {store.address || store.city || 'المغرب'}</p></div></div><form className="public-form booking-form" onSubmit={submitBooking}><h3>طلب حجز موعد</h3><label>الاسم الكامل<input required name="name" value={booking.name} onChange={setBookingField} minLength={2} maxLength={100}/></label><label>رقم الهاتف<input required name="phone" type="tel" value={booking.phone} onChange={setBookingField} pattern="[+0-9 ()-]{8,20}"/></label><label>الخدمة<select name="service" value={booking.service} onChange={setBookingField}><option>اختيار النظارات</option><option>ضبط وصيانة النظارات</option><option>استشارة بصرية</option><option>استلام الطلب</option></select></label><div className="booking-date-grid"><label>التاريخ<input required type="date" name="date" min={today} value={booking.date} onChange={setBookingField}/></label><label>الوقت<input required type="time" name="time" value={booking.time} onChange={setBookingField}/></label></div><button className="public-submit" disabled={busy}>{busy ? 'جارٍ إرسال الطلب…' : <>إرسال طلب الموعد <CalendarDays size={17}/></>}</button></form></section>}
    </main>
    <footer className="public-footer"><div><b>{store.name}</b><p>{settings.address || store.address || store.city}</p></div><div><b>تواصل معنا</b><p>{settings.phone || store.phone}</p>{wa && <a href={`https://wa.me/${wa}`} target="_blank" rel="noreferrer">راسلنا عبر واتساب</a>}</div><small>© {new Date().getFullYear()} {store.name}. جميع الحقوق محفوظة.</small></footer>
  </div>;
}
