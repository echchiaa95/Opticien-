import React from 'react';
import { ArrowLeft, ArrowUpLeft, CalendarDays, Check, ChevronLeft, Glasses, LayoutDashboard, Package, ShieldCheck, ShoppingBag, Store, TrendingUp, Wallet, Users, Sparkles } from 'lucide-react';
import './public-home.css';

const features = [
  { icon: Package, title: 'المخزون والمنتجات', text: 'تتبع النظارات والعدسات والإكسسوارات، مع تنبيهات عند انخفاض المخزون.' },
  { icon: ShoppingBag, title: 'الطلبات والمبيعات', text: 'نظّم الطلبات من لحظة تسجيلها حتى التسليم، وتابع حالة كل عملية بسهولة.' },
  { icon: CalendarDays, title: 'المواعيد والعملاء', text: 'استقبل طلبات حجز المواعيد واحتفظ ببيانات العملاء في مكان واحد.' },
  { icon: Wallet, title: 'المالية والتقارير', text: 'تابع المصاريف والمبيعات والتقارير لمساعدتك على اتخاذ قرارات أوضح.' },
  { icon: Store, title: 'متجر إلكتروني خاص', text: 'أنشئ واجهة لمحلّك تعرض المنتجات وتتيح الطلب والدفع عند الاستلام.' },
  { icon: ShieldCheck, title: 'حساب مستقل لكل محل', text: 'مساحة عمل مستقلة لكل متجر بصلاحيات تناسب مدير المحل وفريقه.' },
];

export default function PublicHome() {
  const base = window.location.pathname;
  const goAdmin = () => { window.location.href = `${base}?admin=1`; };
  return <div className="home-site" dir="rtl">
    <header className="home-nav">
      <a className="home-logo" href={base}><span><Glasses size={25}/></span><b>OPTIC<span>FLOW</span></b></a>
      <nav><a href="#features">المميزات</a><a href="#how">كيف يعمل؟</a><a href="#plans">الباقات</a></nav>
      <div className="home-nav-actions"><button className="home-login" onClick={goAdmin}>دخول المنصة</button><button className="home-cta small" onClick={goAdmin}>ابدأ الآن <ArrowLeft size={16}/></button></div>
    </header>
    <main>
      <section className="home-hero">
        <div className="home-hero-copy"><span className="home-kicker"><Sparkles size={15}/> منصة إدارة محلات البصريات</span><h1>كل ما يحتاجه محلّك،<br/><em>في منصة واحدة.</em></h1><p>أدر المنتجات والمخزون والمبيعات والمواعيد والعملاء، وامنح محلّك واجهة متجر إلكتروني احترافية — من لوحة تحكم واحدة وبكل سهولة.</p><div className="home-hero-actions"><button className="home-cta" onClick={goAdmin}>الدخول إلى المنصة <ArrowLeft size={17}/></button><a className="home-secondary" href="#features">اكتشف المميزات <ChevronLeft size={17}/></a></div><div className="home-proof"><span><Check size={15}/> إدارة من مكان واحد</span><span><Check size={15}/> واجهة خاصة لمتجرك</span><span><Check size={15}/> تصميم متجاوب للهاتف</span></div></div>
        <div className="home-visual" aria-label="تصميم توضيحي للوحة إدارة OpticFlow"><div className="visual-glow"/><div className="visual-orbit orbit-a"/><div className="visual-orbit orbit-b"/><div className="visual-glasses"><Glasses size={150} strokeWidth={1.15}/></div><div className="visual-card visual-card-top"><span className="visual-card-icon"><TrendingUp size={18}/></span><div><small>نظرة عامة</small><b>إدارة محلك بوضوح</b></div><span className="visual-live"/></div><div className="visual-card visual-card-bottom"><span className="visual-card-icon gold"><ShoppingBag size={18}/></span><div><small>الطلبات والمبيعات</small><b>كل شيء في مكانه</b></div><ArrowUpLeft size={18}/></div><div className="visual-mini-stats"><span><Package size={16}/> المخزون</span><span><CalendarDays size={16}/> المواعيد</span><span><Wallet size={16}/> المالية</span></div></div>
      </section>
      <section className="home-trust"><div><b>إدارة متكاملة</b><span>لعمليات محل البصريات اليومية</span></div><div><b>متجر إلكتروني</b><span>اعرض منتجاتك واستقبل الطلبات</span></div><div><b>لوحة تحكم مستقلة</b><span>لكل محل وحساباته الخاصة</span></div></section>
      <section className="home-features" id="features"><div className="home-section-heading"><span>مميزات OPTICFLOW</span><h2>من تفاصيل المخزون إلى تجربة العميل</h2><p>أدوات عملية تساعدك على تنظيم العمل وتقديم تجربة أفضل لعملائك.</p></div><div className="home-feature-grid">{features.map(({icon:Icon,title,text})=><article className="home-feature" key={title}><span className="feature-icon"><Icon size={22}/></span><h3>{title}</h3><p>{text}</p></article>)}</div></section>
      <section className="home-how" id="how"><div className="home-how-copy"><span>بسيطة من البداية</span><h2>ابدأ بإدارة أكثر تنظيمًا</h2><p>سجّل الدخول إلى المنصة، وأنشئ مساحة العمل الخاصة بمحلّك، ثم خصّص واجهتك وابدأ بإدارة منتجاتك وطلباتك.</p><button className="home-cta" onClick={goAdmin}>افتح لوحة المنصة <ArrowLeft size={17}/></button></div><div className="home-steps"><div><b>01</b><section><h3>إعداد حساب المحل</h3><p>تجهيز معلومات المحل وبيانات التواصل.</p></section></div><div><b>02</b><section><h3>إضافة المنتجات والخدمات</h3><p>تنظيم المخزون وإعداد المواعيد والطلبات.</p></section></div><div><b>03</b><section><h3>إطلاق واجهتك الإلكترونية</h3><p>عرض المنتجات واستقبال طلبات العملاء.</p></section></div></div></section>
      <section className="home-plans" id="plans"><div><span>جاهز للانطلاق؟</span><h2>اجعل إدارة محلّك أسهل مع OpticFlow</h2><p>انتقل إلى المنصة لاكتشاف لوحة الإدارة وإعداد مساحة العمل الخاصة بك.</p></div><button className="home-cta light" onClick={goAdmin}>دخول المنصة <ArrowLeft size={17}/></button></section>
    </main>
    <footer className="home-footer"><a className="home-logo" href={base}><span><Glasses size={22}/></span><b>OPTIC<span>FLOW</span></b></a><p>منصة ذكية لإدارة محلات البصريات.</p><small>© {new Date().getFullYear()} OpticFlow — جميع الحقوق محفوظة</small></footer>
  </div>;
}
