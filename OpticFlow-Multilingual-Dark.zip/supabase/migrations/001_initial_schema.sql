-- OpticFlow multi-tenant schema for Supabase/PostgreSQL
-- Run this migration in the Supabase SQL Editor after reviewing it.
create extension if not exists pgcrypto;

create type public.platform_role as enum ('superadmin','shop_admin','shop_staff');
create type public.shop_status as enum ('pending','active','suspended');
create type public.order_status as enum ('new','confirmed','preparing','shipped','delivered','cancelled','returned');
create type public.appointment_status as enum ('pending','confirmed','attended','cancelled','no_show');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role public.platform_role not null default 'shop_admin',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.optical_shops (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique,
  owner_name text not null default '',
  contact_email text,
  phone text,
  whatsapp text,
  city text,
  address text,
  status public.shop_status not null default 'pending',
  logo_url text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.shop_members (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.optical_shops(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.platform_role not null default 'shop_admin',
  created_at timestamptz not null default now(),
  unique(shop_id,user_id)
);
create table public.shop_settings (
  shop_id uuid primary key references public.optical_shops(id) on delete cascade,
  tagline text default 'Votre vision, notre priorité',
  hero_title text default 'رؤيتك أوضح. إطلالتك أجمل.',
  hero_text text default '',
  primary_color text default '#172f46',
  accent_color text default '#c6a66b',
  email text,
  phone text,
  whatsapp text,
  address text,
  opening_hours jsonb not null default '{}'::jsonb,
  delivery_fee numeric(12,2) not null default 0 check (delivery_fee >= 0),
  currency text not null default 'MAD',
  locale text not null default 'ar',
  social_links jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
create table public.subscription_plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  monthly_price numeric(12,2) not null default 0 check(monthly_price >= 0),
  yearly_price numeric(12,2) not null default 0 check(yearly_price >= 0),
  features jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.shop_subscriptions (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.optical_shops(id) on delete cascade,
  plan_id uuid references public.subscription_plans(id) on delete set null,
  status text not null default 'trial' check(status in ('trial','active','past_due','cancelled','expired')),
  billing_period text not null default 'monthly' check(billing_period in ('monthly','yearly')),
  starts_at date not null default current_date,
  ends_at date,
  amount numeric(12,2) not null default 0 check(amount >= 0),
  created_at timestamptz not null default now()
);
create table public.products (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.optical_shops(id) on delete cascade,
  name text not null,
  description text,
  category text not null default 'نظارات طبية',
  sku text,
  brand text,
  price numeric(12,2) not null check(price >= 0),
  cost_price numeric(12,2) not null default 0 check(cost_price >= 0),
  stock integer not null default 0 check(stock >= 0),
  image_urls jsonb not null default '[]'::jsonb,
  options jsonb not null default '{}'::jsonb,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(shop_id,sku)
);
create table public.customers (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.optical_shops(id) on delete cascade,
  full_name text not null,
  phone text not null,
  email text,
  city text,
  address text,
  notes text,
  created_at timestamptz not null default now(),
  unique(shop_id,phone)
);
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.optical_shops(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  order_number text not null,
  customer_name text not null,
  customer_phone text not null,
  customer_city text,
  customer_address text,
  status public.order_status not null default 'new',
  payment_method text not null default 'cod' check(payment_method in ('cod','cash','card','transfer')),
  payment_status text not null default 'unpaid' check(payment_status in ('unpaid','pending_collection','paid','refunded','partially_refunded')),
  subtotal numeric(12,2) not null default 0 check(subtotal >= 0),
  delivery_fee numeric(12,2) not null default 0 check(delivery_fee >= 0),
  discount numeric(12,2) not null default 0 check(discount >= 0),
  total numeric(12,2) not null default 0 check(total >= 0),
  delivery_company text,
  tracking_number text,
  notes text,
  delivered_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(shop_id,order_number)
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  sku text,
  quantity integer not null check(quantity > 0),
  unit_price numeric(12,2) not null check(unit_price >= 0),
  unit_cost numeric(12,2) not null default 0 check(unit_cost >= 0),
  line_total numeric(12,2) not null check(line_total >= 0)
);
create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.optical_shops(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  customer_name text not null,
  customer_phone text not null,
  service text not null,
  starts_at timestamptz not null,
  ends_at timestamptz,
  status public.appointment_status not null default 'pending',
  notes text,
  created_at timestamptz not null default now()
);
create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.optical_shops(id) on delete cascade,
  title text not null,
  category text not null default 'general',
  amount numeric(12,2) not null check(amount > 0),
  expense_date date not null default current_date,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create table public.cash_transactions (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.optical_shops(id) on delete cascade,
  transaction_type text not null check(transaction_type in ('opening','sale','expense','supplier_payment','cod_collection','refund','adjustment')),
  direction text not null check(direction in ('in','out')),
  amount numeric(12,2) not null check(amount > 0),
  reference_type text,
  reference_id uuid,
  description text,
  occurred_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);
create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  shop_id uuid references public.optical_shops(id) on delete set null,
  action text not null,
  entity_type text,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index products_shop_idx on public.products(shop_id);
create index orders_shop_created_idx on public.orders(shop_id,created_at desc);
create index appointments_shop_starts_idx on public.appointments(shop_id,starts_at);
create index expenses_shop_date_idx on public.expenses(shop_id,expense_date desc);
create index members_user_idx on public.shop_members(user_id);

create or replace function public.is_superadmin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles p where p.id = auth.uid() and p.role = 'superadmin'::public.platform_role); $$;
create or replace function public.has_shop_access(target_shop uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select public.is_superadmin() or exists(select 1 from public.shop_members m where m.shop_id = target_shop and m.user_id = auth.uid()); $$;
revoke all on function public.is_superadmin() from public;
revoke all on function public.has_shop_access(uuid) from public;
grant execute on function public.is_superadmin() to authenticated;
grant execute on function public.has_shop_access(uuid) to authenticated;

-- Create a profile automatically. New users are NOT superadmins by default.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  insert into public.profiles(id,full_name,phone,role)
  values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.raw_user_meta_data->>'phone', 'shop_admin')
  on conflict(id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.optical_shops enable row level security;
alter table public.shop_members enable row level security;
alter table public.shop_settings enable row level security;
alter table public.subscription_plans enable row level security;
alter table public.shop_subscriptions enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.appointments enable row level security;
alter table public.expenses enable row level security;
alter table public.cash_transactions enable row level security;
alter table public.audit_logs enable row level security;

create policy "profiles read self or superadmin" on public.profiles for select to authenticated using(id=auth.uid() or public.is_superadmin());
create policy "profiles update self or superadmin" on public.profiles for update to authenticated using(id=auth.uid() or public.is_superadmin()) with check((id=auth.uid() and role <> 'superadmin'::public.platform_role) or public.is_superadmin());
create policy "shops read by members or superadmin" on public.optical_shops for select to authenticated using(public.has_shop_access(id));
create policy "shops create by superadmin" on public.optical_shops for insert to authenticated with check(public.is_superadmin());
create policy "shops update by superadmin" on public.optical_shops for update to authenticated using(public.is_superadmin()) with check(public.is_superadmin());
create policy "shops delete by superadmin" on public.optical_shops for delete to authenticated using(public.is_superadmin());
create policy "members read own shop or superadmin" on public.shop_members for select to authenticated using(user_id=auth.uid() or public.is_superadmin() or public.has_shop_access(shop_id));
create policy "members manage by superadmin" on public.shop_members for all to authenticated using(public.is_superadmin()) with check(public.is_superadmin());
create policy "settings read by shop" on public.shop_settings for select to authenticated using(public.has_shop_access(shop_id));
create policy "settings manage by shop" on public.shop_settings for all to authenticated using(public.has_shop_access(shop_id)) with check(public.has_shop_access(shop_id));
create policy "active plans readable" on public.subscription_plans for select to authenticated using(active or public.is_superadmin());
create policy "plans managed by superadmin" on public.subscription_plans for all to authenticated using(public.is_superadmin()) with check(public.is_superadmin());
create policy "subscriptions read by shop" on public.shop_subscriptions for select to authenticated using(public.has_shop_access(shop_id));
create policy "subscriptions managed by superadmin" on public.shop_subscriptions for all to authenticated using(public.is_superadmin()) with check(public.is_superadmin());
create policy "products read by shop" on public.products for select to authenticated using(public.has_shop_access(shop_id));
create policy "products manage by shop" on public.products for all to authenticated using(public.has_shop_access(shop_id)) with check(public.has_shop_access(shop_id));
create policy "customers read by shop" on public.customers for select to authenticated using(public.has_shop_access(shop_id));
create policy "customers manage by shop" on public.customers for all to authenticated using(public.has_shop_access(shop_id)) with check(public.has_shop_access(shop_id));
create policy "orders read by shop" on public.orders for select to authenticated using(public.has_shop_access(shop_id));
create policy "orders manage by shop" on public.orders for all to authenticated using(public.has_shop_access(shop_id)) with check(public.has_shop_access(shop_id));
create policy "order items via parent order" on public.order_items for all to authenticated using(exists(select 1 from public.orders o where o.id=order_id and public.has_shop_access(o.shop_id))) with check(exists(select 1 from public.orders o where o.id=order_id and public.has_shop_access(o.shop_id)));
create policy "appointments read by shop" on public.appointments for select to authenticated using(public.has_shop_access(shop_id));
create policy "appointments manage by shop" on public.appointments for all to authenticated using(public.has_shop_access(shop_id)) with check(public.has_shop_access(shop_id));
create policy "expenses read by shop" on public.expenses for select to authenticated using(public.has_shop_access(shop_id));
create policy "expenses manage by shop" on public.expenses for all to authenticated using(public.has_shop_access(shop_id)) with check(public.has_shop_access(shop_id));
create policy "cash transactions read by shop" on public.cash_transactions for select to authenticated using(public.has_shop_access(shop_id));
create policy "cash transactions manage by shop" on public.cash_transactions for all to authenticated using(public.has_shop_access(shop_id)) with check(public.has_shop_access(shop_id));
create policy "audit logs read by superadmin or shop" on public.audit_logs for select to authenticated using(public.is_superadmin() or (shop_id is not null and public.has_shop_access(shop_id)));
create policy "audit logs insert authenticated" on public.audit_logs for insert to authenticated with check(actor_id=auth.uid() and (shop_id is null and public.is_superadmin() or shop_id is not null and public.has_shop_access(shop_id)));
-- Intentionally no UPDATE/DELETE policy on audit_logs.

insert into public.subscription_plans(code,name,monthly_price,yearly_price,features) values
('basic','Basic',99,990,'{"storefront":true,"inventory":true,"orders":true,"appointments":true,"reports":"basic"}'),
('pro','Pro',199,1990,'{"storefront":true,"inventory":true,"orders":true,"appointments":true,"reports":"advanced","customization":true}'),
('premium','Premium',349,3490,'{"storefront":true,"inventory":true,"orders":true,"appointments":true,"reports":"advanced","customization":true,"priority_support":true}')
on conflict(code) do nothing;
