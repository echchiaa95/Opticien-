-- Public storefront, COD checkout, and appointment RPCs.
-- All price and stock validation is performed inside PostgreSQL, never trusted from the browser.

create index if not exists products_public_shop_idx on public.products(shop_id, published) where published = true;
create index if not exists appointments_active_slot_idx on public.appointments(shop_id, starts_at) where status not in ('cancelled'::public.appointment_status, 'no_show'::public.appointment_status);

create or replace function public.get_public_storefront(p_slug text)
returns jsonb
language plpgsql
stable
security definer
set search_path = public, pg_temp
as $$
declare
  v_shop public.optical_shops%rowtype;
  v_settings public.shop_settings%rowtype;
  v_products jsonb;
begin
  if p_slug is null or length(trim(p_slug)) < 2 or length(p_slug) > 100 then
    return jsonb_build_object('error', 'invalid_slug');
  end if;
  select * into v_shop from public.optical_shops where slug = lower(trim(p_slug)) and status = 'active' limit 1;
  if not found then return jsonb_build_object('error', 'not_found'); end if;
  select * into v_settings from public.shop_settings where shop_id = v_shop.id;
  select coalesce(jsonb_agg(jsonb_build_object(
    'id', p.id, 'name', p.name, 'description', p.description, 'category', p.category,
    'brand', p.brand, 'price', p.price, 'stock', p.stock, 'image_urls', p.image_urls
  ) order by p.created_at desc), '[]'::jsonb)
  into v_products from public.products p
  where p.shop_id = v_shop.id and p.published = true and p.stock > 0;
  return jsonb_build_object(
    'shop', jsonb_build_object(
      'id', v_shop.id, 'name', v_shop.name, 'slug', v_shop.slug, 'owner_name', v_shop.owner_name,
      'phone', v_shop.phone, 'whatsapp', v_shop.whatsapp, 'city', v_shop.city, 'address', v_shop.address, 'logo_url', v_shop.logo_url,
      'settings', jsonb_build_object(
        'tagline', coalesce(v_settings.tagline, 'Votre vision, notre priorité'),
        'hero_title', coalesce(v_settings.hero_title, 'رؤيتك أوضح. إطلالتك أجمل.'),
        'hero_text', coalesce(v_settings.hero_text, ''), 'primary_color', coalesce(v_settings.primary_color, '#172f46'),
        'accent_color', coalesce(v_settings.accent_color, '#c6a66b'), 'delivery_fee', coalesce(v_settings.delivery_fee, 0),
        'locale', coalesce(v_settings.locale, 'ar'), 'phone', coalesce(v_settings.phone, v_shop.phone),
        'whatsapp', coalesce(v_settings.whatsapp, v_shop.whatsapp), 'address', coalesce(v_settings.address, v_shop.address)
      )
    ), 'products', v_products
  );
end;
$$;

create or replace function public.create_public_cod_order(p_slug text, p_customer jsonb, p_items jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_shop public.optical_shops%rowtype;
  v_settings public.shop_settings%rowtype;
  v_item jsonb;
  v_product public.products%rowtype;
  v_customer_id uuid;
  v_order_id uuid;
  v_order_number text;
  v_qty integer;
  v_subtotal numeric(12,2) := 0;
  v_delivery numeric(12,2) := 0;
  v_total numeric(12,2);
  v_name text;
  v_phone text;
  v_city text;
  v_address text;
  v_items_count integer := 0;
begin
  if p_customer is null or jsonb_typeof(p_customer) <> 'object' or p_items is null or jsonb_typeof(p_items) <> 'array' then
    return jsonb_build_object('error', 'بيانات الطلب غير صالحة');
  end if;
  v_name := trim(coalesce(p_customer->>'name',''));
  v_phone := regexp_replace(coalesce(p_customer->>'phone',''), '[^0-9+]', '', 'g');
  v_city := trim(coalesce(p_customer->>'city',''));
  v_address := trim(coalesce(p_customer->>'address',''));
  if length(v_name) < 2 or length(v_name) > 100 or length(v_phone) < 8 or length(v_phone) > 20 or length(v_city) < 2 or length(v_city) > 80 or length(v_address) < 5 or length(v_address) > 300 then
    return jsonb_build_object('error', 'يرجى إدخال الاسم والهاتف والمدينة والعنوان بشكل صحيح');
  end if;
  if jsonb_array_length(p_items) < 1 or jsonb_array_length(p_items) > 30 then
    return jsonb_build_object('error', 'عدد المنتجات في الطلب غير صالح');
  end if;
  select * into v_shop from public.optical_shops where slug = lower(trim(p_slug)) and status = 'active' limit 1;
  if not found then return jsonb_build_object('error', 'المتجر غير متاح'); end if;
  if (select count(*) from public.orders o where o.shop_id = v_shop.id and o.customer_phone = v_phone and o.created_at > now() - interval '24 hours') >= 5 then
    return jsonb_build_object('error', 'تم بلوغ الحد اليومي للطلبات من هذا الرقم. تواصل مع المحل للمساعدة.');
  end if;
  select * into v_settings from public.shop_settings where shop_id = v_shop.id;
  v_delivery := coalesce(v_settings.delivery_fee, 0);

  -- Serialize checkout attempts for this shop; each product is also row-locked below.
  perform pg_advisory_xact_lock(hashtext(v_shop.id::text), hashtext('public_cod_checkout'));
  insert into public.customers(shop_id, full_name, phone, city, address)
  values(v_shop.id, v_name, v_phone, v_city, v_address)
  on conflict(shop_id, phone) do update set full_name = excluded.full_name, city = excluded.city, address = excluded.address
  returning id into v_customer_id;

  v_order_number := 'OF-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 10));
  insert into public.orders(shop_id, customer_id, order_number, customer_name, customer_phone, customer_city, customer_address, status, payment_method, payment_status, subtotal, delivery_fee, total)
  values(v_shop.id, v_customer_id, v_order_number, v_name, v_phone, v_city, v_address, 'new', 'cod', 'unpaid', 0, v_delivery, 0)
  returning id into v_order_id;

  for v_item in select value from jsonb_array_elements(p_items) loop
    if coalesce(v_item->>'product_id','') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
      raise exception 'منتج غير صالح';
    end if;
    begin v_qty := (v_item->>'quantity')::integer; exception when others then raise exception 'كمية غير صالحة'; end;
    if v_qty < 1 or v_qty > 20 then raise exception 'الكمية المطلوبة غير صالحة'; end if;
    select * into v_product from public.products where id = (v_item->>'product_id')::uuid and shop_id = v_shop.id and published = true for update;
    if not found then raise exception 'أحد المنتجات لم يعد متاحًا'; end if;
    if v_product.stock < v_qty then raise exception 'الكمية المتاحة من % غير كافية', v_product.name; end if;
    update public.products set stock = stock - v_qty, updated_at = now() where id = v_product.id;
    insert into public.order_items(order_id, product_id, product_name, sku, quantity, unit_price, unit_cost, line_total)
    values(v_order_id, v_product.id, v_product.name, v_product.sku, v_qty, v_product.price, v_product.cost_price, v_product.price * v_qty);
    v_subtotal := v_subtotal + (v_product.price * v_qty);
    v_items_count := v_items_count + 1;
  end loop;
  if v_items_count = 0 then raise exception 'السلة فارغة'; end if;
  v_total := v_subtotal + v_delivery;
  update public.orders set subtotal = v_subtotal, total = v_total, updated_at = now() where id = v_order_id;
  insert into public.audit_logs(shop_id, action, entity_type, entity_id, details)
  values(v_shop.id, 'public_cod_order_created', 'order', v_order_id::text, jsonb_build_object('order_number', v_order_number, 'total', v_total));
  return jsonb_build_object('ok', true, 'order_id', v_order_id, 'order_number', v_order_number, 'total', v_total, 'currency', 'MAD');
exception when others then
  -- PostgreSQL rolls back all writes in this function when an exception escapes.
  raise;
end;
$$;

create or replace function public.create_public_appointment(p_slug text, p_customer jsonb, p_service text, p_starts_at timestamptz)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_shop public.optical_shops%rowtype;
  v_name text;
  v_phone text;
  v_appointment_id uuid;
  v_end timestamptz;
begin
  if p_customer is null or jsonb_typeof(p_customer) <> 'object' then return jsonb_build_object('error', 'بيانات العميل غير صالحة'); end if;
  v_name := trim(coalesce(p_customer->>'name',''));
  v_phone := regexp_replace(coalesce(p_customer->>'phone',''), '[^0-9+]', '', 'g');
  if length(v_name) < 2 or length(v_name) > 100 or length(v_phone) < 8 or length(v_phone) > 20 then
    return jsonb_build_object('error', 'يرجى إدخال الاسم ورقم الهاتف بشكل صحيح');
  end if;
  if p_service is null or length(trim(p_service)) < 3 or length(p_service) > 100 then return jsonb_build_object('error', 'نوع الخدمة غير صالح'); end if;
  if p_starts_at is null or p_starts_at < now() + interval '30 minutes' or p_starts_at > now() + interval '90 days' then
    return jsonb_build_object('error', 'اختر موعدًا بعد 30 دقيقة وخلال 90 يومًا');
  end if;
  select * into v_shop from public.optical_shops where slug = lower(trim(p_slug)) and status = 'active' limit 1;
  if not found then return jsonb_build_object('error', 'المتجر غير متاح'); end if;
  if (select count(*) from public.appointments a where a.shop_id = v_shop.id and a.customer_phone = v_phone and a.created_at > now() - interval '24 hours') >= 5 then
    return jsonb_build_object('error', 'تم بلوغ الحد اليومي لطلبات الحجز من هذا الرقم. تواصل مع المحل للمساعدة.');
  end if;
  v_end := p_starts_at + interval '30 minutes';
  perform pg_advisory_xact_lock(hashtext(v_shop.id::text), hashtext(to_char(p_starts_at at time zone 'UTC', 'YYYY-MM-DD-HH24')));
  if exists(select 1 from public.appointments a where a.shop_id = v_shop.id and a.status not in ('cancelled','no_show') and a.starts_at < v_end and coalesce(a.ends_at, a.starts_at + interval '30 minutes') > p_starts_at) then
    return jsonb_build_object('error', 'هذا الوقت غير متاح. اختر وقتًا آخر.');
  end if;
  insert into public.appointments(shop_id, customer_name, customer_phone, service, starts_at, ends_at, status)
  values(v_shop.id, v_name, v_phone, trim(p_service), p_starts_at, v_end, 'pending') returning id into v_appointment_id;
  insert into public.audit_logs(shop_id, action, entity_type, entity_id, details)
  values(v_shop.id, 'public_appointment_created', 'appointment', v_appointment_id::text, jsonb_build_object('starts_at', p_starts_at, 'service', p_service));
  return jsonb_build_object('ok', true, 'appointment_id', v_appointment_id, 'status', 'pending');
end;
$$;

revoke all on function public.get_public_storefront(text) from public;
revoke all on function public.create_public_cod_order(text, jsonb, jsonb) from public;
revoke all on function public.create_public_appointment(text, jsonb, text, timestamptz) from public;
grant execute on function public.get_public_storefront(text) to anon, authenticated;
grant execute on function public.create_public_cod_order(text, jsonb, jsonb) to anon, authenticated;
grant execute on function public.create_public_appointment(text, jsonb, text, timestamptz) to anon, authenticated;

-- Prevent overlapping appointments even when two guests submit at nearly the same time.
create extension if not exists btree_gist;
do $$ begin
  alter table public.appointments add constraint appointments_no_overlapping_active_slots
  exclude using gist (
    shop_id with =,
    tstzrange(starts_at, coalesce(ends_at, starts_at + interval '30 minutes'), '[)') with &&
  ) where (status not in ('cancelled'::public.appointment_status, 'no_show'::public.appointment_status));
exception when duplicate_object then null;
end $$;

-- Permit shop owners to edit only their own public business profile (never its status).
create policy "shop admins update own shop profile" on public.optical_shops
for update to authenticated
using (exists (select 1 from public.shop_members m where m.shop_id = optical_shops.id and m.user_id = auth.uid() and m.role = 'shop_admin'))
with check (exists (select 1 from public.shop_members m where m.shop_id = optical_shops.id and m.user_id = auth.uid() and m.role = 'shop_admin'));

-- A cancelled COD order releases its reserved stock exactly once.
alter table public.orders add column if not exists inventory_restored boolean not null default false;
create or replace function public.restore_stock_for_cancelled_order()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if old.status = 'cancelled' and new.status <> 'cancelled' then
    raise exception 'لا يمكن إعادة فتح طلب ملغى تلقائيًا؛ أنشئ طلبًا جديدًا أو عالج المخزون يدويًا';
  end if;
  if old.status <> 'cancelled' and new.status = 'cancelled' and not old.inventory_restored then
    update public.products p
    set stock = p.stock + x.qty, updated_at = now()
    from (
      select product_id, sum(quantity)::integer as qty
      from public.order_items
      where order_id = old.id and product_id is not null
      group by product_id
    ) x
    where p.id = x.product_id and p.shop_id = old.shop_id;
    new.inventory_restored := true;
  end if;
  return new;
end;
$$;
drop trigger if exists orders_restore_stock_on_cancel on public.orders;
create trigger orders_restore_stock_on_cancel
before update of status on public.orders
for each row execute function public.restore_stock_for_cancelled_order();

-- Separate read access from write access: shop_staff may read assigned shop data but cannot mutate it.
create or replace function public.can_manage_shop(target_shop uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp
as $$
  select public.is_superadmin() or exists (
    select 1 from public.shop_members m
    where m.shop_id = target_shop and m.user_id = auth.uid() and m.role = 'shop_admin'::public.platform_role
  );
$$;
revoke all on function public.can_manage_shop(uuid) from public;
grant execute on function public.can_manage_shop(uuid) to authenticated;

drop policy if exists "settings manage by shop" on public.shop_settings;
create policy "settings manage by shop admin" on public.shop_settings for all to authenticated
using (public.can_manage_shop(shop_id)) with check (public.can_manage_shop(shop_id));
drop policy if exists "products manage by shop" on public.products;
create policy "products manage by shop admin" on public.products for all to authenticated
using (public.can_manage_shop(shop_id)) with check (public.can_manage_shop(shop_id));
drop policy if exists "customers manage by shop" on public.customers;
create policy "customers manage by shop admin" on public.customers for all to authenticated
using (public.can_manage_shop(shop_id)) with check (public.can_manage_shop(shop_id));
drop policy if exists "orders manage by shop" on public.orders;
create policy "orders manage by shop admin" on public.orders for all to authenticated
using (public.can_manage_shop(shop_id)) with check (public.can_manage_shop(shop_id));
drop policy if exists "appointments manage by shop" on public.appointments;
create policy "appointments manage by shop admin" on public.appointments for all to authenticated
using (public.can_manage_shop(shop_id)) with check (public.can_manage_shop(shop_id));
drop policy if exists "expenses manage by shop" on public.expenses;
create policy "expenses manage by shop admin" on public.expenses for all to authenticated
using (public.can_manage_shop(shop_id)) with check (public.can_manage_shop(shop_id));
drop policy if exists "cash transactions manage by shop" on public.cash_transactions;
create policy "cash transactions manage by shop admin" on public.cash_transactions for all to authenticated
using (public.can_manage_shop(shop_id)) with check (public.can_manage_shop(shop_id));

create or replace function public.prevent_shop_admin_status_change()
returns trigger language plpgsql security definer set search_path = public, pg_temp
as $$
begin
  if auth.uid() is not null and not public.is_superadmin() and (new.status is distinct from old.status or new.created_by is distinct from old.created_by) then
    raise exception 'Only Superadmin can change shop status or creator';
  end if;
  return new;
end;
$$;
drop trigger if exists optical_shops_protect_status on public.optical_shops;
create trigger optical_shops_protect_status before update on public.optical_shops
for each row execute function public.prevent_shop_admin_status_change();

drop policy if exists "order items via parent order" on public.order_items;
create policy "order items read by assigned shop" on public.order_items for select to authenticated
using (exists(select 1 from public.orders o where o.id = order_id and public.has_shop_access(o.shop_id)));
create policy "order items manage by shop admin" on public.order_items for all to authenticated
using (exists(select 1 from public.orders o where o.id = order_id and public.can_manage_shop(o.shop_id)))
with check (exists(select 1 from public.orders o where o.id = order_id and public.can_manage_shop(o.shop_id)));
drop policy if exists "audit logs insert authenticated" on public.audit_logs;
create policy "audit logs insert by shop admins" on public.audit_logs for insert to authenticated
with check (actor_id = auth.uid() and ((shop_id is null and public.is_superadmin()) or (shop_id is not null and public.can_manage_shop(shop_id))));

-- Prevent a user from promoting their own profile by editing profiles.role.
create or replace function public.prevent_self_role_change()
returns trigger language plpgsql security definer set search_path = public, pg_temp
as $$
begin
  if new.role is distinct from old.role and not public.is_superadmin() then
    raise exception 'Only Superadmin can change platform roles';
  end if;
  return new;
end;
$$;
drop trigger if exists profiles_protect_role on public.profiles;
create trigger profiles_protect_role before update of role on public.profiles
for each row execute function public.prevent_self_role_change();
