-- OpticFlow hardening migration. Apply after 001 and 002.
-- Shop admins may edit public-facing profile fields only. Status, creator, slug,
-- and tenant ownership remain under server-side Superadmin control.

revoke update on table public.optical_shops from public, anon, authenticated;
grant update (name, phone, whatsapp, contact_email, address, logo_url, updated_at)
  on table public.optical_shops to authenticated;

-- Explicitly keep public RPCs callable only by the intended roles.
revoke all on function public.get_public_storefront(text) from public;
revoke all on function public.create_public_cod_order(text, jsonb, jsonb) from public;
revoke all on function public.create_public_appointment(text, jsonb, text, timestamptz) from public;
grant execute on function public.get_public_storefront(text) to anon, authenticated;
grant execute on function public.create_public_cod_order(text, jsonb, jsonb) to anon, authenticated;
grant execute on function public.create_public_appointment(text, jsonb, text, timestamptz) to anon, authenticated;

-- Ensure shop staff can read their assigned shop but cannot mutate financial,
-- stock, order, appointment, settings, or customer records through broad grants.
-- RLS policies from migration 002 remain the row-level enforcement layer.

-- Avoid accidental duplicate cash-ledger references if a later collection workflow
-- records the same order/expense more than once.
create unique index if not exists cash_transactions_reference_once_idx
  on public.cash_transactions(shop_id, transaction_type, reference_type, reference_id)
  where reference_id is not null and reference_type is not null;

-- A COD delivery is not automatically a confirmed collection. Keep payment_status
-- separate from order status so finance reports do not recognize unpaid COD as cash.
comment on column public.orders.payment_status is
  'Collection state is separate from delivery status; mark COD as paid only after the carrier/cash collection is verified.';
