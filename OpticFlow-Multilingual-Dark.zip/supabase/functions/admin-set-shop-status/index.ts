import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  const url = Deno.env.get('SUPABASE_URL'), anon = Deno.env.get('SUPABASE_ANON_KEY'), service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anon || !service) return json({ error: 'Server configuration missing' }, 500);
  const auth = req.headers.get('Authorization'); if (!auth?.startsWith('Bearer ')) return json({ error: 'Authentication required' }, 401);
  const caller = createClient(url, anon, { auth: { persistSession: false } });
  const { data: authData, error: authError } = await caller.auth.getUser(auth.slice(7));
  if (authError || !authData.user) return json({ error: 'Invalid session' }, 401);
  const admin = createClient(url, service, { auth: { persistSession: false } });
  const { data: profile } = await admin.from('profiles').select('role').eq('id', authData.user.id).maybeSingle();
  if (profile?.role !== 'superadmin') return json({ error: 'Superadmin access required' }, 403);
  let body: { shop_id?: string; status?: string };
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }
  if (!body.shop_id || !['active', 'pending', 'suspended'].includes(body.status || '')) return json({ error: 'Valid shop_id and status are required' }, 400);
  const { data, error } = await admin.from('optical_shops').update({ status: body.status, updated_at: new Date().toISOString() }).eq('id', body.shop_id).select('id,name,status').single();
  if (error) return json({ error: error.message }, 400);
  await admin.from('audit_logs').insert({ actor_id: authData.user.id, shop_id: body.shop_id, action: 'shop.status_changed', entity_type: 'optical_shop', entity_id: body.shop_id, details: { status: body.status } });
  return json({ shop: data });
});
