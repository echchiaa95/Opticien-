import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});
const slugify = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48);

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const url = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anonKey || !serviceKey) return json({ error: 'Server configuration missing' }, 500);

  const authorization = req.headers.get('Authorization');
  if (!authorization?.startsWith('Bearer ')) return json({ error: 'Authentication required' }, 401);

  // Verify the caller's JWT with Supabase Auth; never trust a role sent by the browser.
  const token = authorization.slice('Bearer '.length);
  const authClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: userError } = await authClient.auth.getUser(token);
  if (userError || !userData.user) return json({ error: 'Invalid session' }, 401);

  const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: profile, error: profileError } = await admin.from('profiles')
    .select('role').eq('id', userData.user.id).maybeSingle();
  if (profileError) return json({ error: 'Unable to verify permissions' }, 500);
  if (profile?.role !== 'superadmin') return json({ error: 'Superadmin access required' }, 403);

  let input: Record<string, unknown>;
  try { input = await req.json(); } catch { return json({ error: 'Invalid JSON body' }, 400); }
  const name = String(input.name ?? '').trim().slice(0, 120);
  const ownerName = String(input.owner_name ?? '').trim().slice(0, 120);
  const email = String(input.email ?? '').trim().toLowerCase().slice(0, 254);
  const phone = String(input.phone ?? '').trim().slice(0, 40);
  const city = String(input.city ?? '').trim().slice(0, 100);
  const planCode = String(input.plan ?? 'basic').trim().toLowerCase();
  const status = input.status === 'active' ? 'active' : 'pending';
  const period = input.billing_period === 'yearly' ? 'yearly' : 'monthly';
  if (!name || !ownerName || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return json({ error: 'Valid shop name, owner name, and email are required' }, 400);
  }
  if (!['basic', 'pro', 'premium'].includes(planCode)) return json({ error: 'Invalid plan' }, 400);

  const { data: plan, error: planError } = await admin.from('subscription_plans')
    .select('id,monthly_price,yearly_price').eq('code', planCode).eq('active', true).maybeSingle();
  if (planError || !plan) return json({ error: 'Selected plan is unavailable' }, 400);

  let createdUserId: string | null = null;
  let createdShopId: string | null = null;
  try {
    // Invite, rather than choosing a password on behalf of the owner.
    const { data: invite, error: inviteError } = await admin.auth.admin.inviteUserByEmail(email, {
      data: { full_name: ownerName, phone },
    });
    if (inviteError || !invite.user) throw new Error(inviteError?.message || 'Could not invite owner');
    createdUserId = invite.user.id;

    const baseSlug = slugify(String(input.slug ?? name)) || `optic-${crypto.randomUUID().slice(0, 8)}`;
    let slug = baseSlug;
    const { data: existing } = await admin.from('optical_shops').select('id').eq('slug', slug).maybeSingle();
    if (existing) slug = `${baseSlug}-${crypto.randomUUID().slice(0, 6)}`;

    const { data: shop, error: shopError } = await admin.from('optical_shops').insert({
      name, slug, owner_name: ownerName, contact_email: email, phone, whatsapp: phone,
      city, status, created_by: userData.user.id,
    }).select('id,name,slug,status').single();
    if (shopError || !shop) throw new Error(shopError?.message || 'Could not create shop');
    createdShopId = shop.id;

    const { error: memberError } = await admin.from('shop_members').insert({
      shop_id: shop.id, user_id: createdUserId, role: 'shop_admin',
    });
    if (memberError) throw new Error(memberError.message);

    const { error: settingsError } = await admin.from('shop_settings').insert({
      shop_id: shop.id, email, phone, whatsapp: phone, address: city,
      hero_title: 'رؤيتك أوضح. إطلالتك أجمل.', locale: 'ar', currency: 'MAD',
    });
    if (settingsError) throw new Error(settingsError.message);

    const amount = period === 'yearly' ? plan.yearly_price : plan.monthly_price;
    const end = new Date();
    if (period === 'yearly') end.setFullYear(end.getFullYear() + 1); else end.setMonth(end.getMonth() + 1);
    const { error: subscriptionError } = await admin.from('shop_subscriptions').insert({
      shop_id: shop.id, plan_id: plan.id, status: 'active', billing_period: period,
      starts_at: new Date().toISOString().slice(0, 10), ends_at: end.toISOString().slice(0, 10), amount,
    });
    if (subscriptionError) throw new Error(subscriptionError.message);

    await admin.from('audit_logs').insert({
      actor_id: userData.user.id, shop_id: shop.id, action: 'shop.created', entity_type: 'optical_shop',
      entity_id: shop.id, details: { email, plan: planCode, billing_period: period, status },
    });
    return json({ shop, owner_user_id: createdUserId, invitation_sent: true }, 201);
  } catch (error) {
    // Best-effort cleanup so a partial shop setup is not left behind.
    if (createdShopId) await admin.from('optical_shops').delete().eq('id', createdShopId);
    if (createdUserId) await admin.auth.admin.deleteUser(createdUserId);
    return json({ error: error instanceof Error ? error.message : 'Shop creation failed' }, 400);
  }
});
