import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Relative asset paths work both on a domain root and on GitHub Pages project URLs.
export default defineConfig({ plugins: [react()], base: './' });
