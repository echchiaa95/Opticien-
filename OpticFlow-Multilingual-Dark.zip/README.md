# OpticFlow — Opticien Multi-Shop Platform

A responsive React + Vite starter for managing multiple optical shops from one platform. Includes a Superadmin console, shop-management interface, storefront customization preview, product/inventory CRUD in demo state, COD order workflow, appointment management, customer view, expense tracking, analytics previews, Supabase schema/RLS, and a GitHub Pages workflow.

> **Important scope note:** Without Supabase configuration the dashboard uses sample/demo data and edits are not persisted. When Supabase is configured, the dashboard requires authentication rather than showing demo records. Public storefront reads, COD checkout with database-side price/stock checks, and appointment overlap checks are implemented in migration 002. Before commercial use, deploy the Edge Functions, run both migrations, test the full flows, and complete the remaining production checks below.

## Requirements
- Node.js 20+
- A Supabase project for authentication and persistent data
- GitHub repository (optional, for deployment)

## Run locally
1. Extract the ZIP.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your Supabase Project URL and **anon/publishable key** to `.env`.
5. Run `npm run dev` and open the URL Vite prints.
6. Run `npm run build` to test a production build.

Never put a Supabase `service_role` key in a Vite environment variable or client-side code.

## Supabase setup
1. Create a Supabase project.
2. Open SQL Editor and run migrations in order: `001_initial_schema.sql`, `002_public_storefront_checkout.sql`, then `003_security_hardening.sql`.
3. In Authentication settings, configure the site URL and redirect URLs for local development and your deployed site.
4. Create your first administrator using Supabase Auth. Then promote that user to `superadmin` through the SQL Editor using the exact verified Auth user UUID:

```sql
-- Replace with the UUID of the administrator you created in Supabase Auth.
update public.profiles set role = 'superadmin' where id = 'REPLACE-WITH-REAL-USER-UUID';
```

5. Deploy the included Edge Functions from the project root using the Supabase CLI:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy admin-create-shop
supabase functions deploy admin-set-shop-status
```

6. The Edge Functions use the Supabase server environment and check the caller’s verified session plus `profiles.role = superadmin` before using the Admin Auth API. The create-shop function invites the owner by email, creates the shop, membership, settings, subscription, and audit event, then attempts cleanup if setup fails. Test invitation delivery and failure paths in your own Supabase project before production. Never put a `service_role` key in the browser.
7. The add-shop form calls `admin-create-shop` when Supabase is configured. Without Supabase, it remains a clearly labelled local demo and does not create real accounts. Shop status changes call `admin-set-shop-status`.
8. Review RLS policies before production. Public storefront reads and guest COD order/appointment submissions need narrowly scoped RPCs or Edge Functions with validation and rate limits; do not turn off RLS or expose all customer data to anonymous users.

## GitHub Pages deployment
1. Push the project contents to the root of a GitHub repository on the `main` branch.
2. In repository Settings → Pages, choose GitHub Actions as the build/deploy source.
3. In Settings → Secrets and variables → Actions, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. The workflow in `.github/workflows/deploy.yml` installs dependencies, builds and deploys the `dist` folder on push or manual dispatch. Relative Vite asset paths are configured for GitHub Pages project URLs.
5. Supabase Auth redirect URLs must include the final GitHub Pages URL. For a project site, remember the URL includes the repository path.

## Roles and tenant isolation
- `superadmin`: manage platform shops, membership, subscription plans and subscriptions.
- `shop_admin`: access records for assigned shop(s), manage products, orders, appointments and finances.
- `shop_staff`: currently a role placeholder; implement narrower action permissions before staff accounts are enabled.
- Shop-owned tables use `shop_id`; RLS calls `has_shop_access(shop_id)` to prevent cross-shop access.
- The first superadmin is promoted manually from the SQL Editor. Signup metadata cannot grant superadmin privileges.

## Included modules
- `Superadmin`: shop list, sample platform analytics, account overview, subscription plan overview, platform settings, audit log preview.
- `Shop admin`: storefront preview/customization, products, COD orders, appointments, customers, expenses and financial summaries.
- SQL schema for profiles, shops, membership, settings, plans, subscriptions, products, customers, orders/items, appointments, expenses, cash transactions and audit logs.

## Edge Functions included
- `supabase/functions/admin-create-shop/index.ts`: verifies the bearer token and Superadmin role, invites the owner, creates the shop and membership, default settings, subscription, and audit entry.
- `supabase/functions/admin-set-shop-status/index.ts`: verifies Superadmin authorization before activating, suspending, or setting a shop to pending.

These functions are source files; they are not deployed to your Supabase project automatically by GitHub Pages. Deploy them with the Supabase CLI and test email delivery. The app still contains demo datasets for several operational screens; those screens must be wired to real database reads/writes before using them as business records.

## Production checklist
- Verify the included server-side Superadmin provisioning and shop-status Edge Functions with a real Supabase project; add dedicated invite resend and password-reset flows.
- Load all pages from Supabase with pagination, error/loading/empty states; persist mutations with validated queries/RPCs.
- Add public shop slug routing and a secure public catalog query.
- Build guest checkout RPC/Edge Function with stock validation and atomic inventory reservation; validate total price on server.
- Add appointment availability checks on the server to prevent double-booking.
- Add Supabase Storage policies for shop logos/product photos.
- Add real financial postings, supplier invoices, delivery remittance reconciliation, tax settings and export generation.
- Add audit writes for every sensitive admin action and alerting for failed operations.
- Configure backups, CAPTCHA/rate limits, privacy notice, retention rules and production monitoring.
- Replace demo metrics and sample customers/orders before real use.

## Project structure
```
src/main.jsx                 React dashboard and UI
src/style.css                Responsive styling
src/supabase.js              Supabase client configuration
supabase/migrations/         PostgreSQL schema and RLS
.github/workflows/deploy.yml GitHub Actions build/deploy
.env.example                 Environment variable template
```

## Public storefront, COD checkout, and appointments (added)

Run migrations in order:
1. `supabase/migrations/001_initial_schema.sql`
2. `supabase/migrations/002_public_storefront_checkout.sql`
3. `supabase/migrations/003_security_hardening.sql`

The second migration adds:
- `get_public_storefront(p_slug)` to expose only an active shop's published products and public settings.
- `create_public_cod_order(p_slug, p_customer, p_items)` to recalculate prices server-side, lock products, check stock, create the COD order and line items, and reserve stock atomically.
- `create_public_appointment(p_slug, p_customer, p_service, p_starts_at)` to validate appointment requests and prevent overlapping active appointments.
- An exclusion constraint against overlapping appointment ranges, daily per-phone request limits, stock restoration when an order is cancelled, and stronger shop-admin / staff write separation.

After a shop is active, its public store URL is:
`https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY/?store=SHOP_SLUG`

The `SHOP_SLUG` is created by the `admin-create-shop` Edge Function. Public orders and appointments use the SQL RPCs above, so do not create broad anonymous `SELECT` policies on customers, orders, or appointments.

## Deploying the Supabase Edge Functions

Install the Supabase CLI and log in, then link your project and deploy both administrative functions:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy admin-create-shop
supabase functions deploy admin-set-shop-status
```

The platform supplies `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` to Edge Functions. Never expose the service-role key in GitHub Pages, `.env` variables beginning with `VITE_`, or client code.

## Production checks before accepting real customers

- Configure Supabase Auth redirect URLs for the exact GitHub Pages URL.
- Create the first Auth user, then promote its exact UUID to `superadmin` using the SQL statement above.
- Test account invitation and activation with a separate test shop before creating customer accounts.
- Publish only products whose price, stock, images, and descriptions are verified.
- Test checkout with a disposable product and verify the order, line items, stock reservation, cancellation restoration, and order totals in the database.
- Test overlapping appointment submissions in two browser sessions.
- Configure CAPTCHA / edge rate limiting, monitoring, backups, privacy notices, and a retention policy before production use. The SQL functions include basic per-phone daily limits but this is not a substitute for CAPTCHA or infrastructure-level rate limiting.
- GitHub Pages is a static host. It cannot keep secret keys or run server code; all privileged work must remain in Supabase Edge Functions / PostgreSQL.

## Public shop preview

Open the deployed root with `?store=SHOP_SLUG`. The storefront reads live data from the `get_public_storefront` RPC and supports a product catalog, cart, COD checkout, and appointment request. When Supabase is not configured, the public store displays a setup message instead of pretending to accept orders.


## آخر مراجعة أمنية (27 أكتوبر 2026)

- أضيفت `003_security_hardening.sql` لتقييد أعمدة تعديل بيانات المحل من جهة المستخدم، مع إبقاء تغيير حالة المحل وملكيته ضمن وظائف Superadmin الخادمية.
- تم تشديد واجهة الدخول: لا تُعرض لوحة الإدارة قبل التحقق من دور المستخدم؛ وعند فشل التحقق تُعرض صفحة منع الوصول بدل الرجوع إلى دور Superadmin افتراضي.
- تم منع واجهة الموظف من تنفيذ تعديلات محلية مضللة على المنتجات والطلبات والمواعيد والمصاريف والإعدادات.
- تم إصلاح مطابقة حالة الطلب «تم الشحن» مع القيمة المخزنة `shipped`، وحفظ ساعات العمل ضمن `opening_hours`.
- تم فصل حالة تسليم طلب COD عن حالة تحصيل المال؛ التسليم وحده لا يثبت أن شركة التوصيل حولت المبلغ للصندوق.

### حالة الاختبار
تم فحص ملفات JSX وJavaScript وTypeScript نحويًا باستخدام TypeScript transpilation. تعذر تثبيت اعتماديات npm في بيئة البناء بسبب انتهاء المهلة؛ لذلك لم يُؤكّد بناء Vite النهائي أو تشغيل migrations على مشروع Supabase حي.
